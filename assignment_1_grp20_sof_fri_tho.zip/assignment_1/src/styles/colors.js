export const blue = '#13CDC1';
export const lightyellow = '#F6F096';
export const babyblue = '#96F6F6';
export const lightestblue = '#BBFAFA';
export const bgwhite = '#f2f2f2';
