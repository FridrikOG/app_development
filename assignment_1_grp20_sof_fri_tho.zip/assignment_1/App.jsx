import React from 'react';
import AppContainer from './src/routes';

export default function App() {
  return (
    <AppContainer />
  );
}
