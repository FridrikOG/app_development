import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const NestedApp= () => {
  return (
    <View>
      <Text>Info from NestedApp</Text>
    </View>
  )
};
  
export default NestedApp;

